'use server'

import { revalidatePath } from "next/cache"
import { and, desc, eq } from "drizzle-orm"
import { z } from "zod"
import { requireAuthenticatedUser } from "@/lib/auth-session"
import { db } from "@/lib/db"
import { brandReviews, brandSources, reviewEvents } from "@/lib/schema"
import { findOwnedReview, serializeEvent, serializeReview, serializeSource } from "@/lib/workspace-data"
import { createReviewVersionSnapshot, latestReviewVersionNumber, reviewVersionFromEvent } from "@/lib/review-history"
import type { ReviewStatus, SourceStatus } from "@/lib/types"

const sourceInputSchema = z.object({
  kind: z.enum(["guideline", "fact", "terminology", "asset"]),
  title: z.string().trim().min(3).max(100),
  body: z.string().trim().min(12).max(6000),
  sourceLabel: z.string().trim().max(120).optional().default("Workspace source"),
  sourceUrl: z.string().trim().max(500).optional().default(""),
})

export async function createSource(input: unknown) {
  const user = await requireAuthenticatedUser()
  const parsed = sourceInputSchema.safeParse(input)
  if (!parsed.success) {
    return { source: null, error: "Add a title and at least 12 characters of source guidance." }
  }

  let sourceUrl: string | null = null
  if (parsed.data.sourceUrl) {
    try {
      const url = new URL(parsed.data.sourceUrl)
      if (url.protocol !== "https:" && url.protocol !== "http:") {
        return { source: null, error: "Source links must use HTTP or HTTPS." }
      }
      sourceUrl = url.toString()
    } catch {
      return { source: null, error: "Enter a valid source URL or leave it blank." }
    }
  }

  const [row] = await db
    .insert(brandSources)
    .values({
      id: crypto.randomUUID(),
      userId: user.id,
      kind: parsed.data.kind,
      title: parsed.data.title,
      body: parsed.data.body,
      status: "draft",
      sourceLabel: parsed.data.sourceLabel || "Workspace source",
      sourceUrl,
      metadata: { createdBy: "workspace_owner" },
    })
    .returning()

  revalidatePath("/")
  return { source: serializeSource(row), error: null }
}

export async function updateSourceStatus(sourceId: string, status: SourceStatus) {
  const user = await requireAuthenticatedUser()
  if (!sourceId || sourceId.length > 160 || !["approved", "draft", "archived"].includes(status)) {
    return { source: null, error: "That source update is not valid." }
  }

  const [row] = await db
    .update(brandSources)
    .set({ status, updatedAt: new Date() })
    .where(and(eq(brandSources.id, sourceId), eq(brandSources.userId, user.id)))
    .returning()

  if (!row) return { source: null, error: "Source not found." }
  revalidatePath("/")
  return { source: serializeSource(row), error: null }
}

export async function applySuggestion(reviewId: string, findingId: string) {
  const user = await requireAuthenticatedUser()
  const review = await findOwnedReview(user.id, reviewId)
  if (!review) return { review: null, error: "Review not found." }

  const finding = review.findings.find((candidate) => candidate.id === findingId)
  if (!finding?.sourceId || !finding.originalText || !finding.suggestedText) {
    return { review: null, error: "This finding doesn't have a safe, source-backed replacement to apply." }
  }

  const matchIndex = review.draft.indexOf(finding.originalText)
  if (matchIndex < 0 || review.draft.indexOf(finding.originalText, matchIndex + finding.originalText.length) >= 0) {
    return { review: null, error: "The source text changed or appears more than once. Edit the draft manually, then run the review again." }
  }

  const updatedDraft =
    review.draft.slice(0, matchIndex) +
    finding.suggestedText +
    review.draft.slice(matchIndex + finding.originalText.length)
  const updatedAt = new Date()

  const updated = await db.transaction(async (tx) => {
    const historyRows = await tx
      .select({ details: reviewEvents.details })
      .from(reviewEvents)
      .where(and(eq(reviewEvents.reviewId, reviewId), eq(reviewEvents.userId, user.id)))
      .orderBy(desc(reviewEvents.createdAt))
      .limit(100)
    let latestVersion = latestReviewVersionNumber(historyRows)
    const savedEvents: (typeof reviewEvents.$inferSelect)[] = []

    if (latestVersion === 0) {
      const [baseline] = await tx.insert(reviewEvents).values({
        id: crypto.randomUUID(),
        userId: user.id,
        reviewId,
        event: "revision_baseline",
        actor: user.name || user.email,
        details: { version: createReviewVersionSnapshot(serializeReview(review), 1) },
        createdAt: review.updatedAt,
      }).returning()
      if (baseline) savedEvents.push(baseline)
      latestVersion = 1
    }

    const [row] = await tx
      .update(brandReviews)
      .set({
        draft: updatedDraft,
        status: "needs_review" satisfies ReviewStatus,
        score: 0,
        summary: "Draft changed. Run the review again to refresh findings before approval.",
        findings: [],
        updatedAt,
      })
      .where(and(eq(brandReviews.id, reviewId), eq(brandReviews.userId, user.id)))
      .returning()

    if (!row) return null

    const [eventRow] = await tx.insert(reviewEvents).values({
      id: crypto.randomUUID(),
      userId: user.id,
      reviewId,
      event: "suggestion_applied",
      actor: user.name || user.email,
      details: {
        findingId,
        sourceId: finding.sourceId,
        version: createReviewVersionSnapshot(serializeReview(row), latestVersion + 1),
      },
      createdAt: updatedAt,
    }).returning()
    if (eventRow) savedEvents.push(eventRow)

    return { row, events: savedEvents }
  })

  if (!updated) return { review: null, error: "Review not found." }
  revalidatePath("/")
  const events = updated.events.map(serializeEvent)
  return {
    review: serializeReview(updated.row),
    events,
    versions: events.map(reviewVersionFromEvent).filter((version) => version !== null),
    error: null,
  }
}

export async function decideReview(reviewId: string, decision: "approved" | "changes_requested") {
  const user = await requireAuthenticatedUser()
  if (decision !== "approved" && decision !== "changes_requested") {
    return { review: null, error: "Choose a valid review decision." }
  }

  const existing = await findOwnedReview(user.id, reviewId)
  if (!existing) return { review: null, error: "Review not found." }
  if (decision === "approved" && existing.summary.startsWith("Draft changed.")) {
    return { review: null, error: "Run the review again before approving this changed draft." }
  }

  const updatedAt = new Date()
  const nextStatus: ReviewStatus = decision
  const updated = await db.transaction(async (tx) => {
    const [row] = await tx
      .update(brandReviews)
      .set({ status: nextStatus, updatedAt })
      .where(and(eq(brandReviews.id, reviewId), eq(brandReviews.userId, user.id)))
      .returning()

    if (!row) return null

    const [eventRow] = await tx.insert(reviewEvents).values({
      id: crypto.randomUUID(),
      userId: user.id,
      reviewId,
      event: decision,
      actor: user.name || user.email,
      details: {
        score: existing.score,
        findingCount: existing.findings.filter((finding) => finding.severity !== "pass").length,
        overrodeOpenFindings:
          decision === "approved" && existing.status === "needs_review" &&
          existing.findings.some((finding) => finding.severity === "high" || finding.severity === "medium"),
      },
      createdAt: updatedAt,
    }).returning()

    return { row, event: eventRow }
  })

  if (!updated) return { review: null, error: "Review not found." }
  revalidatePath("/")
  return {
    review: serializeReview(updated.row),
    event: updated.event ? serializeEvent(updated.event) : null,
    error: null,
  }
}

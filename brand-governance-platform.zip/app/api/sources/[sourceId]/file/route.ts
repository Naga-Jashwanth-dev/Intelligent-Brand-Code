import { get } from "@vercel/blob"
import { and, eq } from "drizzle-orm"
import { NextResponse } from "next/server"
import { requireAuthenticatedUser } from "@/lib/auth-session"
import { db } from "@/lib/db"
import { brandSources } from "@/lib/schema"

export const runtime = "nodejs"

export async function GET(
  _request: Request,
  { params }: { params: Promise<{ sourceId: string }> },
) {
  try {
    const user = await requireAuthenticatedUser()
    const { sourceId } = await params
    if (!sourceId || sourceId.length > 160) {
      return NextResponse.json({ error: "Document not found." }, { status: 404 })
    }

    const [source] = await db
      .select({ metadata: brandSources.metadata })
      .from(brandSources)
      .where(and(eq(brandSources.id, sourceId), eq(brandSources.userId, user.id)))
      .limit(1)

    const documentValue = source?.metadata.document
    if (!documentValue || typeof documentValue !== "object" || Array.isArray(documentValue)) {
      return NextResponse.json({ error: "Document not found." }, { status: 404 })
    }

    const document = documentValue as Record<string, unknown>
    const pathname = document.pathname
    const filename = typeof document.name === "string" ? document.name : "brand-guidelines"
    const expectedPrefix = `users/${encodeURIComponent(user.id)}/brand-guidelines/`
    if (typeof pathname !== "string" || !pathname.startsWith(expectedPrefix)) {
      return NextResponse.json({ error: "Document not found." }, { status: 404 })
    }

    const result = await get(pathname, { access: "private" })
    if (!result) {
      return NextResponse.json({ error: "Document not found." }, { status: 404 })
    }

    const safeFilename = filename.replace(/["\\\r\n]/g, "_")
    return new NextResponse(result.stream, {
      headers: {
        "Content-Type": result.blob.contentType || "application/octet-stream",
        "Content-Disposition": `attachment; filename="${safeFilename}"; filename*=UTF-8''${encodeURIComponent(filename)}`,
        "Cache-Control": "private, no-store",
        "X-Content-Type-Options": "nosniff",
      },
    })
  } catch (error) {
    if (error instanceof Error && error.message === "Unauthorized") {
      return NextResponse.json({ error: "Sign in to access this document." }, { status: 401 })
    }
    const errorName = error instanceof Error ? error.name : "UnknownError"
    console.error("[v0] Brand guideline download failed:", errorName)
    return NextResponse.json({ error: "We couldn't access this document." }, { status: 500 })
  }
}

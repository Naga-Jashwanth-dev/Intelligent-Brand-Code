import { del, put } from "@vercel/blob"
import { NextResponse } from "next/server"
import { revalidatePath } from "next/cache"
import { db } from "@/lib/db"
import { brandSources } from "@/lib/schema"
import { requireAuthenticatedUser } from "@/lib/auth-session"
import { extractBrandKnowledge, formatBrandKnowledge, getSupportedDocument } from "@/lib/brand-document"
import { serializeSource } from "@/lib/workspace-data"

export const runtime = "nodejs"
export const maxDuration = 90

const maxFileSize = 8 * 1024 * 1024

function sanitizeFilename(filename: string) {
  return filename.normalize("NFKC").replace(/[\\/\u0000-\u001f]/g, "").slice(0, 160) || "brand-guidelines"
}

function titleFromFilename(filename: string) {
  const title = filename.replace(/\.[^.]+$/, "").replace(/[_-]+/g, " ").trim().slice(0, 100)
  return title.length >= 3 ? title : "Uploaded brand guidelines"
}

export async function POST(request: Request) {
  let storedPathname: string | null = null

  try {
    const user = await requireAuthenticatedUser()
    const contentLength = Number(request.headers.get("content-length") ?? 0)
    if (contentLength > maxFileSize + 500_000) {
      return NextResponse.json({ error: "Guideline files must be smaller than 8 MB." }, { status: 413 })
    }

    const formData = await request.formData()
    const uploadedValue = formData.get("file")
    const file = typeof File !== "undefined" && uploadedValue instanceof File && uploadedValue.size > 0
      ? uploadedValue
      : null
    if (!file) {
      return NextResponse.json({ error: "Choose a PDF, DOCX, TXT, or Markdown file." }, { status: 400 })
    }
    if (file.size > maxFileSize) {
      return NextResponse.json({ error: "Guideline files must be smaller than 8 MB." }, { status: 413 })
    }

    const documentType = getSupportedDocument(file.name)
    if (!documentType) {
      return NextResponse.json({ error: "Use a PDF, DOCX, TXT, or Markdown file." }, { status: 400 })
    }

    const filename = sanitizeFilename(file.name)
    const bytes = new Uint8Array(await file.arrayBuffer())
    let knowledge
    try {
      knowledge = await extractBrandKnowledge({
        bytes,
        extension: documentType.extension,
        filename,
      })
    } catch (error) {
      const errorName = error instanceof Error ? error.name : "UnknownError"
      console.error("[v0] Brand guideline extraction failed:", errorName)
      return NextResponse.json({
        error: "We couldn't extract this document. Check that it contains readable text, then retry or use a TXT export.",
      }, { status: 422 })
    }

    const pathname = `users/${encodeURIComponent(user.id)}/brand-guidelines/${crypto.randomUUID()}/${filename}`
    const blob = await put(pathname, file, {
      access: "private",
      addRandomSuffix: false,
      contentType: documentType.mediaType,
    })
    storedPathname = blob.pathname

    const [row] = await db
      .insert(brandSources)
      .values({
        id: crypto.randomUUID(),
        userId: user.id,
        kind: "guideline",
        title: titleFromFilename(filename),
        body: formatBrandKnowledge(knowledge),
        status: "draft",
        sourceLabel: "Uploaded guideline",
        sourceUrl: null,
        metadata: {
          createdBy: "document_upload",
          brandKnowledge: knowledge,
          document: {
            name: filename,
            mediaType: documentType.mediaType,
            size: file.size,
            pathname: blob.pathname,
          },
        },
      })
      .returning()

    if (!row) throw new Error("Source insert failed")
    revalidatePath("/")
    return NextResponse.json({ source: serializeSource(row) })
  } catch (error) {
    if (storedPathname) {
      try {
        await del(storedPathname)
      } catch {
        // Keep the original upload error; private storage cleanup is best-effort.
      }
    }
    if (error instanceof Error && error.message === "Unauthorized") {
      return NextResponse.json({ error: "Sign in to upload brand documents." }, { status: 401 })
    }
    const errorName = error instanceof Error ? error.name : "UnknownError"
    console.error("[v0] Brand guideline upload failed:", errorName)
    return NextResponse.json({ error: "We couldn't save this guideline. Please try again." }, { status: 500 })
  }
}

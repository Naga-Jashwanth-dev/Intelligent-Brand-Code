import { headers } from "next/headers"
import { redirect } from "next/navigation"
import { AuthForm } from "@/components/auth-form"
import { auth } from "@/lib/auth"

export default async function SignInPage() {
  const session = await auth.api.getSession({ headers: await headers() })
  if (session?.user) redirect("/")

  const demoAccounts = [
    {
      id: "user" as const,
      label: "User Demo",
      description: "Explore the standard user review workflow.",
      email: "brandguard-demo@example.com",
      password: "Garden-Review-2026!",
    },
    {
      id: "verification" as const,
      label: "Verification Demo",
      description: "Test review changes in a workspace separate from User Demo.",
      email: "verification-demo@example.com",
      password: "Verify-Workspace-2026!",
    },
  ]

  return <AuthForm mode="sign-in" demoAccounts={demoAccounts} />
}

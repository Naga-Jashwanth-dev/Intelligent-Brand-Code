'use client'

import { useState, type FormEvent } from "react"
import Link from "next/link"
import { useRouter } from "next/navigation"
import { ArrowRight, Check, ShieldCheck, Sparkles } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import {
  Field,
  FieldDescription,
  FieldError,
  FieldGroup,
  FieldLabel,
} from "@/components/ui/field"
import { Input } from "@/components/ui/input"
import { authClient } from "@/lib/auth-client"

type AuthMode = "sign-in" | "sign-up"

type DemoCredentials = {
  email: string
  password: string
}

type DemoAccount = DemoCredentials & {
  id: "user" | "verification"
  label: string
  description: string
}

type AuthFormProps = {
  mode: AuthMode
  demoAccounts?: DemoAccount[]
}

export function AuthForm({ mode, demoAccounts }: AuthFormProps) {
  const router = useRouter()
  const [name, setName] = useState("")
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [error, setError] = useState("")
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [activeDemoId, setActiveDemoId] = useState<string | null>(null)
  const isSignUp = mode === "sign-up"

  async function signInWithCredentials(
    credentials: DemoCredentials,
    isDemo = false,
  ) {
    setError("")
    setIsSubmitting(true)

    try {
      const result = await authClient.signIn.email({
        email: credentials.email.trim(),
        password: credentials.password,
      })

      if (result.error) {
        setError(
          isDemo
            ? "We couldn't open the demo account. Please try again."
            : "We couldn't sign you in. Check your email and password, or use the demo account below.",
        )
        return
      }

      router.replace("/")
      router.refresh()
    } catch {
      setError("We couldn't complete that request. Please try again.")
    } finally {
      setIsSubmitting(false)
    }
  }

  async function handleDemoSignIn(account: DemoAccount) {
    if (isSubmitting) return
    setActiveDemoId(account.id)
    try {
      await signInWithCredentials(account, true)
    } finally {
      setActiveDemoId(null)
    }
  }

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    setError("")

    if (!isSignUp) {
      await signInWithCredentials({ email, password })
      return
    }

    setIsSubmitting(true)

    try {
      const result = await authClient.signUp.email({ name: name.trim(), email: email.trim(), password })

      if (result.error) {
        setError("We couldn't create the account with those details. Check the form and try again.")
        return
      }

      router.replace("/")
      router.refresh()
    } catch {
      setError("We couldn't complete that request. Please try again.")
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <main className="auth-screen">
      <section className="auth-story" aria-label="Intelligent Brand overview">
        <Link href="/sign-in" className="auth-brand" aria-label="Intelligent Brand home">
          <span className="brand-mark" aria-hidden="true"><ShieldCheck /></span>
          <span>Intelligent Brand</span>
        </Link>

        <div className="auth-story__body">
          <div className="auth-story__eyebrow"><Sparkles aria-hidden="true" /> BEFORE YOU PUBLISH</div>
          <h1>Every draft deserves a second set of eyes.</h1>
          <p>
            Give your team a clear, evidence-backed brand review before content reaches the public.
          </p>
          <div className="auth-story__steps" aria-label="Intelligent Brand review steps">
            <span><b>01</b> Know</span>
            <i aria-hidden="true" />
            <span><b>02</b> Check</span>
            <i aria-hidden="true" />
            <span><b>03</b> Approve</span>
          </div>
        </div>

        <div className="auth-story__footer">
          <span><Check aria-hidden="true" /> Explainable findings</span>
          <span><Check aria-hidden="true" /> Human-led approval</span>
          <span><Check aria-hidden="true" /> Private by default</span>
        </div>
        <div className="auth-story__orb auth-story__orb--one" aria-hidden="true" />
        <div className="auth-story__orb auth-story__orb--two" aria-hidden="true" />
      </section>

      <section className="auth-panel">
        <div className="auth-panel__content">
          <p className="eyebrow">YOUR PRIVATE BRAND WORKSPACE</p>
          <h2>{isSignUp ? "Create your workspace" : "Welcome back"}</h2>
          <p className="auth-panel__intro">
            {isSignUp
              ? "Start with a private space for your approved facts, voice, and reviews."
              : "Sign in to review drafts and manage your approved brand sources."}
          </p>

          <Card className="auth-card">
            <CardContent className="auth-card__content">
              <form onSubmit={handleSubmit}>
                <FieldGroup>
                  {isSignUp ? (
                    <Field>
                      <FieldLabel htmlFor="auth-name">Full name</FieldLabel>
                      <Input
                        id="auth-name"
                        name="name"
                        autoComplete="name"
                        placeholder="Jordan Lee"
                        value={name}
                        onChange={(event) => {
                          setName(event.target.value)
                          if (error) setError("")
                        }}
                        minLength={2}
                        maxLength={72}
                        required
                      />
                    </Field>
                  ) : null}

                  <Field>
                    <FieldLabel htmlFor="auth-email">Work email</FieldLabel>
                    <Input
                      id="auth-email"
                      name="email"
                      type="email"
                      autoComplete="email"
                      placeholder="you@company.com"
                      value={email}
                      onChange={(event) => {
                        setEmail(event.target.value)
                        if (error) setError("")
                      }}
                      maxLength={254}
                      required
                    />
                  </Field>

                  <Field>
                    <FieldLabel htmlFor="auth-password">Password</FieldLabel>
                    <Input
                      id="auth-password"
                      name="password"
                      type="password"
                      autoComplete={isSignUp ? "new-password" : "current-password"}
                      placeholder="At least 8 characters"
                      value={password}
                      onChange={(event) => {
                        setPassword(event.target.value)
                        if (error) setError("")
                      }}
                      minLength={8}
                      maxLength={72}
                      required
                    />
                    {isSignUp ? (
                      <FieldDescription>Use 8–72 characters. Your password is handled by Better Auth.</FieldDescription>
                    ) : null}
                  </Field>

                  {error ? <FieldError role="alert">{error}</FieldError> : null}

                  <Button type="submit" size="lg" className="auth-submit" disabled={isSubmitting}>
                    {isSubmitting ? "Working…" : isSignUp ? "Create private workspace" : "Sign in"}
                    {!isSubmitting ? <ArrowRight aria-hidden="true" data-icon="inline-end" /> : null}
                  </Button>
                </FieldGroup>
              </form>
              {!isSignUp && demoAccounts?.length ? (
                <div className="auth-demo-list" role="group" aria-labelledby="auth-demo-heading">
                  <div className="auth-demo-list__intro">
                    <p id="auth-demo-heading" className="auth-demo-list__title">Choose a demo workspace</p>
                    <p className="auth-demo-list__description">Each account keeps its own sample data.</p>
                  </div>
                  {demoAccounts.map((account) => (
                    <div className="auth-demo-option" key={account.id}>
                      <Button
                        type="button"
                        variant="outline"
                        size="lg"
                        className="auth-demo-submit"
                        onClick={() => handleDemoSignIn(account)}
                        disabled={isSubmitting}
                      >
                        {activeDemoId === account.id ? `Opening ${account.label}…` : `Continue as ${account.label}`}
                        {activeDemoId !== account.id ? <ArrowRight aria-hidden="true" data-icon="inline-end" /> : null}
                      </Button>
                      <p>{account.description}</p>
                    </div>
                  ))}
                </div>
              ) : null}
            </CardContent>
          </Card>

          <p className="auth-switch">
            {isSignUp ? "Already have an account?" : "New to Intelligent Brand?"}{" "}
            <Link href={isSignUp ? "/sign-in" : "/sign-up"}>
              {isSignUp ? "Sign in" : "Create an account"}
            </Link>
          </p>
          <p className="auth-privacy-note">
            <ShieldCheck aria-hidden="true" />
            {demoAccounts?.length
              ? "The demos use separate workspaces; changes stay in the selected account. Visitors using the same demo share its data."
              : "Drafts are private to your account."}{" "}
            AI recommendations never approve or publish content.
          </p>
        </div>
      </section>
    </main>
  )
}

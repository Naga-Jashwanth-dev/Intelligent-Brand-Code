import type { BrandReview, ReviewEvent, ReviewStatus, ReviewVersion } from "@/lib/types"

const reviewStatuses = new Set<ReviewStatus>([
  "needs_review",
  "ready",
  "approved",
  "changes_requested",
])

export function createReviewVersionSnapshot(
  review: Pick<BrandReview, "title" | "channel" | "draft" | "status" | "score" | "summary" | "findings">,
  versionNumber: number,
) {
  return {
    versionNumber,
    title: review.title,
    channel: review.channel,
    draft: review.draft,
    status: review.status,
    score: review.score,
    summary: review.summary,
    issueCount: review.findings.filter((finding) => finding.severity !== "pass").length,
  }
}

export function latestReviewVersionNumber(events: Array<{ details: Record<string, unknown> }>) {
  return events.reduce((latest, event) => {
    const snapshot = event.details.version
    if (!snapshot || typeof snapshot !== "object" || Array.isArray(snapshot)) return latest
    const value = (snapshot as Record<string, unknown>).versionNumber
    return typeof value === "number" && Number.isInteger(value) ? Math.max(latest, value) : latest
  }, 0)
}

export function reviewVersionFromEvent(event: ReviewEvent): ReviewVersion | null {
  const value = event.details.version
  if (!value || typeof value !== "object" || Array.isArray(value)) return null

  const snapshot = value as Record<string, unknown>
  const status = snapshot.status
  if (
    typeof snapshot.versionNumber !== "number" ||
    !Number.isInteger(snapshot.versionNumber) ||
    typeof snapshot.title !== "string" ||
    typeof snapshot.channel !== "string" ||
    typeof snapshot.draft !== "string" ||
    typeof snapshot.score !== "number" ||
    typeof snapshot.summary !== "string" ||
    typeof snapshot.issueCount !== "number" ||
    typeof status !== "string" ||
    !reviewStatuses.has(status as ReviewStatus)
  ) {
    return null
  }

  return {
    id: event.id,
    reviewId: event.reviewId,
    versionNumber: snapshot.versionNumber,
    title: snapshot.title,
    channel: snapshot.channel,
    draft: snapshot.draft,
    status: status as ReviewStatus,
    score: snapshot.score,
    summary: snapshot.summary,
    issueCount: snapshot.issueCount,
    actor: event.actor,
    createdAt: event.createdAt,
  }
}

export type SourceKind = "guideline" | "fact" | "terminology" | "asset"
export type SourceStatus = "approved" | "draft" | "archived"
export type ReviewStatus = "needs_review" | "ready" | "approved" | "changes_requested"
export type FindingSeverity = "high" | "medium" | "low" | "pass"

export interface BrandKnowledge {
  summary: string
  brandVoice: string[]
  keyMessages: string[]
  messagingRules: string[]
  approvedTerminology: Array<{
    preferred: string
    alternatives: string[]
    guidance: string
  }>
  restrictions: string[]
  audience: string
}

export interface SourceDocumentMetadata {
  name: string
  mediaType: string
  size: number
}

export interface BrandSourceMetadata extends Record<string, unknown> {
  brandKnowledge?: BrandKnowledge
  document?: SourceDocumentMetadata
}

export interface ReviewFinding {
  id: string
  severity: FindingSeverity
  category: string
  title: string
  excerpt: string
  explanation: string
  recommendation: string
  originalText: string | null
  suggestedText: string | null
  sourceId: string | null
  sourceTitle: string | null
  sourceLabel: string | null
  confidence: number
}

export interface ReviewAttachment {
  name: string
  kind: "image" | "pdf" | "document" | "text"
  mediaType: string
  size: number
  altText: string
}

export interface BrandSource {
  id: string
  kind: SourceKind
  title: string
  body: string
  status: SourceStatus
  sourceLabel: string | null
  sourceUrl: string | null
  metadata: BrandSourceMetadata
  createdAt: string
  updatedAt: string
}

export interface BrandReview {
  id: string
  title: string
  channel: string
  draft: string
  status: ReviewStatus
  score: number
  summary: string
  findings: ReviewFinding[]
  attachment: ReviewAttachment | null
  createdAt: string
  updatedAt: string
}

export interface ReviewVersion {
  id: string
  reviewId: string
  versionNumber: number
  title: string
  channel: string
  draft: string
  status: ReviewStatus
  score: number
  summary: string
  issueCount: number
  actor: string
  createdAt: string
}

export interface ReviewEvent {
  id: string
  reviewId: string
  event: string
  actor: string
  details: Record<string, unknown>
  createdAt: string
}

export interface WorkspaceData {
  sources: BrandSource[]
  reviews: BrandReview[]
  events: ReviewEvent[]
  versions: ReviewVersion[]
}
